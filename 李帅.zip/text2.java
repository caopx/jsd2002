package test01;
//��1��10 �ĺͲ����
public class text2 {

	public static void main(String[] args) {
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum=sum+i;
		}
		System.out.println("sum="+sum);

	}

}
