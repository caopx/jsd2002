package day08;

public class Text2 {public static void main(String[] args) {
	int i=1,num=0;
	for (i=1;i<=10;i++) {
		num = num+i;
	}
	System.out.println("�ܺ�Ϊ��"+num);
}

}