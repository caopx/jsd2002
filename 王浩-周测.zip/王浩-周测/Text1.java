package day08;

public class Text1 {
	public static void main(String[] args) {
	for(int num=9;num>=1;num--) {
		for(int i=1;i<=num;i++) {
		System.out.print(i+"*"+num+"="+i*num+"\t");
	}
	
	System.out.println();
	
}

}
}


