package day08;
import java.util.Arrays;
public class Text3 {
	public static void main(String[] args) {
		//���������
		int arr[]={10,9,1,20,19,30,5};
		int max = arr[0];
		int i,j;
		for(i=1;i<arr.length;i++) {
			if(arr[i]>max) {
				max = arr[i];
			}

		}
		System.out.println("�±�="+i+"  ���ֵ��"+max);
	}
	}
