package work;
//1��10�ĺ�

public class Demo03 {

	public static void main(String[] args) {
		int sum=0;//���
		for (int i = 0; i <=10; i++) {
			sum =sum+i;	
		}
		System.out.println("��Ϊ��"+sum);

		}
	}


